# reports-builder
To Build reports from MySQL and MSSql. Node.js, Express.js and crontab npm module. Mongodb.
